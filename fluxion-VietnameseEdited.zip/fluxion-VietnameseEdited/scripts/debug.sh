#!/ bin / bash

export FLUXIONDebug = 1 export FLUXIONWIKillProcesses =
    1 export FLUXIONWIReloadDriver = 1
