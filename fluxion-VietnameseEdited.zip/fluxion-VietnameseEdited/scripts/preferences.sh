#!/bin/bash

# export FLUXIONAuto=1
# export FLUXIONDebug=1
# export FLUXIONWIKillProcesses=1
# export FLUXIONWIReloadDriver=1
