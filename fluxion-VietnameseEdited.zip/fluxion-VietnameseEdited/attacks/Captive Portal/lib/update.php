<?php
	require_once("authenticator.php");

	switch ($candidate_code) {
		# case "1": echo "false"; break;
		case "2": echo "true"; break;
		default: echo "false"; break;
	}
